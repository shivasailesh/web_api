﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sampleapi.ViewModel
{
    public class UserVM
    {
        public string username { get; set; }
        public string email { get; set; }
        public string contact { get; set; }

    }
}
